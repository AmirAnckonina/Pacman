Pacman - Exercise 1

Amir Anckonina - ID 208423491
Chen Berger - ID 207709809

Extra features:
1. Colorized game option.
2. Collision, winning and loosing - cool printing animations.
3. Adaptable user experience.

ENJOY!

----------------------------------------------------------------------------
----------------------------------------------------------------------------

+Testing scenarios added below:

//TESTING
Sanity tests:

1. Keys funcitionallity - VVV
2. Borders isn't valid - VVV
3. Pausing game - VVV
4. Pacman move through tunnels - VVV
5. Ghosts can't move through tunnels - VVV
6. Eating breadcrumbs - VVV
7. Score updating - VVV
8. Collision situation - VVV
9. Winning game - VVV
* printing results is OK, starting after winning game is ok - VVV
* Winning after loosing - VVV
* Loosing after winning - VVV
10. Loosing game - VVV
11. Messages printing - VVV

Move and Collision functionallity:

1. Pacman running into ghost - all directions - VVV
2. Pacman stays and ghost running into him - all directions - VVV
3. Pacman goes back, forth, and near the tunnenls - VVV
4. Collision near tunnels - VVV
5. Collision near border - VVV
6. Collision on when last breadcrumb left - VVV


Menu Testing:

1. Requsting any key to continue - VVV
2. Menu presentation - VVV
3. Instruction menu presentation and functionallity - VVV
4. EXIT - VVV
5. StaringColorized / Not - VVV
6. Entry Menu functionallity after game - VVV

Colors Testing:

1. Set colors - VVV
2. Breadcrumbz do not painted in other colors - VVV
3. Changing colors - VVV
4. Collision flashes colors are OK - VVV
5. Starting game without colors is OK, even after colorized game - VVV

