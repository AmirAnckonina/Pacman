#pragma once

enum class Direction 
{ 
	UP, 
	DOWN, 
	LEFT, 
	RIGHT, 
	STAY, 
	WRONG_KEY 
};