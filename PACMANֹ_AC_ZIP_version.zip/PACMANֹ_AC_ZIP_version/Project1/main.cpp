#include "ThePacmanGame.h"

using std::cout;
using std::endl;


int main()
{
	ThePacmanGame game;
	game.startGameSessions();
	return 0;
}


